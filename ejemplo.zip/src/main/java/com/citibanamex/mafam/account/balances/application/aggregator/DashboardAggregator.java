/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.aggregator;

import com.citibanamex.mafam.account.balances.application.mapping.CheckingBalanceMap;
import com.citibanamex.mafam.account.balances.application.mapping.FundInvestmentMap;
import com.citibanamex.mafam.account.balances.application.mapping.LoanBalanceMap;
import com.citibanamex.mafam.account.balances.application.mapping.MasterAccountBalanceMap;
import com.citibanamex.mafam.account.balances.application.mapping.RetirementBalanceMap;
import com.citibanamex.mafam.account.balances.application.repository.account.AssociatedAccountsRepository;
import com.citibanamex.mafam.account.balances.application.repository.account.checking.CheckingAccountBalanceRepository;
import com.citibanamex.mafam.account.balances.application.repository.account.funds.FundsInvestmentRepository;
import com.citibanamex.mafam.account.balances.application.repository.account.loan.LoanAccountBalanceRepository;
import com.citibanamex.mafam.account.balances.application.repository.account.master.MasterAccountBalanceRepository;
import com.citibanamex.mafam.account.balances.application.repository.account.retirement.RetirementBalanceRepository;
import com.citibanamex.mafam.account.balances.application.repository.customer.CustomerRepository;
import com.citibanamex.mafam.account.balances.application.request.balance.AccountBalanceRequest;
import com.citibanamex.mafam.account.balances.application.request.balance.AccountDataCenterBalanceRequest;
import com.citibanamex.mafam.account.balances.application.request.customer.AssociatedAccountsRequest;
import com.citibanamex.mafam.account.balances.application.request.customer.DataCenterLocationRequest;
import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.Account;
import com.citibanamex.mafam.account.balances.domain.account.AccountType;
import com.citibanamex.mafam.account.balances.domain.account.checking.CheckingAccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.FundInvestmentBalance;
import com.citibanamex.mafam.account.balances.domain.account.investment.retirement.RetirementBalance;
import com.citibanamex.mafam.account.balances.domain.account.loan.LoanAccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.master.MasterAccountBalance;
import com.citibanamex.mafam.account.balances.domain.customer.AssociatedProfile;

import java.math.BigInteger;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <code>DashboardAggregator</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class DashboardAggregator implements IDashboardAggregator {

  /** discovery service. */
  private Function<String, String> discoveryService;

  /**
   * Creates a new instance of dashboard aggregator.
   *
   * @param discoveryService discovery service
   */
  public DashboardAggregator(Function<String, String> discoveryService) {
    this.discoveryService = discoveryService;
  }

  /**
   * Gets the data center location.
   *
   * @param headers headers
   * @param customerId customer id
   * @return data center location
   */
  public Integer getDataCenterLocation(Map<String, String> headers, String customerId) {

    return new CustomerRepository(headers, new DataCenterLocationRequest("8661664"),
//        "http://localhost:999")
        "https://csmt-api-a-demographic-profile-mx-uat1.cfapps-gt1-dev.lac.nsroot.net")
        .getDataCenterLocation().getDataCenterLocation();
  }

  /**
   * Gets the associated profile.
   *
   * @param headers headers
   * @param customerId customer id
   * @param dataCenterLocation data center location
   * @return associated profile
   */
  public AssociatedProfile getAssociatedProfile(Map<String, String> headers, String customerId,
      int dataCenterLocation) {

    int pageId = 1;
    boolean isThereMoreInformation = false;

    AssociatedProfile customerAssociatedProfile =
        aggregateProfile(headers, customerId, dataCenterLocation, pageId);

    List<Account> accounts = customerAssociatedProfile.getCustomer().getAccounts();
    isThereMoreInformation = customerAssociatedProfile.getCustomer().isMoreInformationFlag();

    while (isThereMoreInformation) {
      AssociatedProfile nextInformation =
          aggregateProfile(headers, customerId, dataCenterLocation, ++pageId);

      accounts.addAll(nextInformation.getCustomer().getAccounts());
      isThereMoreInformation = nextInformation.getCustomer().isMoreInformationFlag();
    }

    return customerAssociatedProfile;
  }

  /**
   * Aggregate profile.
   *
   * @param headers headers
   * @param customerId customer id
   * @param dataCenterLocation data center location
   * @param pageId page id
   * @return associated profile
   */
  private AssociatedProfile aggregateProfile(Map<String, String> headers, String customerId,
      int dataCenterLocation, int pageId) {

    return new AssociatedAccountsRepository(headers,
        new AssociatedAccountsRequest(customerId, dataCenterLocation, pageId),
        "http://localhost:8080").getAssociatedAccounts();
  }

  /**
   * Supply balances.
   *
   * @param headers headers
   * @param accounts accounts
   * @param dataCenter data center location
   * @return supplier
   */
  public Supplier<List<AccountBalance>> supplyBalances(Map<String, String> headers,
      List<Account> accounts, int dataCenter) {
    
    return () -> {
      ConcurrentHashMap<BigInteger, CompletableFuture<AccountBalance>> callMap =
          new ConcurrentHashMap<>();

      for (Account account : accounts) {
        callMap.put(account.getAccountNumber(), getAccountBalance(headers, account, dataCenter));
      }
      
      return Stream.of(callMap.values().toArray(new CompletableFuture[callMap.size()]))
          .map(CompletableFuture::join).map(o -> (AccountBalance) o)
          .collect(Collectors.toList());
    };
  }  
  
  /**
   * Gets the account balance.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return account balance
   */
  private CompletableFuture<AccountBalance> getAccountBalance(Map<String, String> headers, 
      Account account, int dataCenterLocation) {
    
    AccountType accountType = account.getAccountType();
    
    switch (accountType) {      
      case CHECKING:
        return CompletableFuture
            .supplyAsync(checkingBalanceSupplier(headers, account, dataCenterLocation))
            .thenApplyAsync(new CheckingBalanceMap(account));
      case MASTER:
        return CompletableFuture
             .supplyAsync(masterAccountSupplier(headers, account, dataCenterLocation))
             .thenApplyAsync(new MasterAccountBalanceMap(account));
      case FUNDS_INVESTMENT:
        return CompletableFuture
            .supplyAsync(fundInvestmentBalanceSupplier(headers, account, dataCenterLocation))
            .thenApplyAsync(new FundInvestmentMap(account));
      case RETIREMENT:
        return CompletableFuture
            .supplyAsync(retirementBalanceSupplier(headers, account, dataCenterLocation))
            .thenApplyAsync(new RetirementBalanceMap(account));
      case LOAN:
        return CompletableFuture
            .supplyAsync(loanBalanceSupplier(headers, account, dataCenterLocation))
            .thenApplyAsync(new LoanBalanceMap(account));
      default:
        return null;
    }
  }
  
  /**
   * Checking balance supplier.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return supplier
   */
  private Supplier<CheckingAccountBalance> checkingBalanceSupplier(Map<String, String> headers,
      Account account, int dataCenterLocation) {
    
    return new CheckingAccountBalanceRepository(headers, AccountBalanceRequest.builder()
        .accountNumber(account.getAccountNumber().toString())
        .branchId(String.valueOf(account.getDisplayAccountNumber()))
        .dataCenterLocation(dataCenterLocation)
        .build(), "http://acmt-api-a-checking-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net");
  }
  
  /**
   * Loan balance supplier.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return supplier
   */
  private Supplier<LoanAccountBalance> loanBalanceSupplier(Map<String, String> headers,
      Account account, int dataCenterLocation) {
    
    return new LoanAccountBalanceRepository(headers, AccountDataCenterBalanceRequest.builder()
//        .dataCenterLocation(dataCenterLocation)
        .dataCenterLocation(4)
        .account(
            AccountBalanceRequest.builder()
            .accountNumber(String.valueOf(account.getAccountNumber()))
            .branchId("0000")
            .build()).build(), "http://lndt-api-a-loan-payment-history-mx-uat1.cfapps-gt1-dev.lac.nsroot.net");
  }
  
  /**
   * Master account supplier.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return supplier
   */
  private Supplier<MasterAccountBalance> masterAccountSupplier(Map<String, String> headers,
      Account account, int dataCenterLocation) {
    
    return new MasterAccountBalanceRepository(headers, AccountDataCenterBalanceRequest.builder()
        .dataCenterLocation(dataCenterLocation)
        .account(
            AccountBalanceRequest.builder()
            .accountNumber(String.valueOf(account.getAccountNumber()))
            .branchCode(String.valueOf(account.getBranchId()))
            .build()).build(), "http://acmt-api-a-master-account-balance-mx-uat1.cfapps-gt1-dev.lac.nsroot.net");
  }
  
  /**
   * Fund investment balance supplier.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return supplier
   */
  private Supplier<FundInvestmentBalance> fundInvestmentBalanceSupplier(Map<String, String> headers,
      Account account, int dataCenterLocation) {
    
    return new FundsInvestmentRepository(headers, AccountBalanceRequest.builder()
        .accountNumber(account.getAccountNumber().toString())
        .dataCenterLocation(dataCenterLocation)
        .productInstrument(String.valueOf(account.getProductInstrument()))
        .build(), "http://ivmt-api-a-fund-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net");
  }

  /**
   * Retirement balance supplier.
   *
   * @param headers headers
   * @param account account
   * @param dataCenterLocation data center location
   * @return supplier
   */
  private Supplier<RetirementBalance> retirementBalanceSupplier(Map<String, String> headers,
      Account account, int dataCenterLocation) {

    return new RetirementBalanceRepository(headers, AccountBalanceRequest.builder()
        .accountNumber(account.getAccountNumber().toString())
        .dataCenterLocation(dataCenterLocation)
        .build(), "https://ivmt-api-a-retirement-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net");
  }
}
