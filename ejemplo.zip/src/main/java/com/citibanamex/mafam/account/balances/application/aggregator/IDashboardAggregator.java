/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.aggregator;

import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.Account;
import com.citibanamex.mafam.account.balances.domain.customer.AssociatedProfile;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * <code>IBalanceAggregator</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public interface IDashboardAggregator {
  
  /**
   * Gets the data center location.
   *
   * @param headers headers
   * @param customerId customer id
   * @return data center location
   */
  public Integer getDataCenterLocation(Map<String, String> headers, String customerId);
  
  /**
   * Gets the associated profile.
   *
   * @param headers headers
   * @param customerId customer id
   * @param dataCenterLocation data center location
   * @return associated profile
   */
  public AssociatedProfile getAssociatedProfile(Map<String, String> headers, String customerId,
      int dataCenterLocation);
  
  /**
   * Supply balances.
   *
   * @param headers headers
   * @param accounts accounts
   * @param dataCenterLocation data center location
   * @return supplier
   */
  public Supplier<List<AccountBalance>> supplyBalances(
      Map<String, String> headers, List<Account> accounts, int dataCenterLocation);
}
