/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.controller;

import com.citibanamex.mafam.account.balances.application.request.MultiBalanceRequest;
import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.infrastructure.exception.ErrorResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * <code>ContractDefinition</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public interface ContractDefinition {

  /**
   * Retrieve balances.
   *
   * @param clientId client id
   * @param authorization authorization
   * @param accept accept
   * @param uuid uuid
   * @param acceptLanguage accept language
   * @param contentType content type
   * @param channelId channel id
   * @param sid sid
   * @param serviceRequest service request
   * @return response entity
   */
  @ApiOperation(value = "Retrieve balances for specific accounts", 
      notes = "PoC Version", tags = {"Multi-balance"})
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = "The service has succeeded", 
          response = AccountBalance.class),
      @ApiResponse(code = 400, message = "Bad request",  response = ErrorResponse.class),
      @ApiResponse(code = 401, message = "Access not authorized", response = ErrorResponse.class),
      @ApiResponse(code = 404, message = "Resource not found", response = ErrorResponse.class),
      @ApiResponse(code = 500, message = "Internal server error", response = ErrorResponse.class)})
  @RequestMapping(
      value = "/v1/accounts/balances", method = RequestMethod.POST, 
      produces = "application/json", consumes = "application/json")
  public abstract ResponseEntity<List<AccountBalance>> retrieveBalances(String clientId,
      String authorization,
      String accept,
      String uuid,
      String acceptLanguage,
      String contentType,
      String channelId,
      String sid,
      MultiBalanceRequest serviceRequest);
}
