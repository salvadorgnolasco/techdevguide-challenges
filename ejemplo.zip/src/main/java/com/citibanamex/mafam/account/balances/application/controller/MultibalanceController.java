/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.controller;

import com.citibanamex.mafam.account.balances.application.request.MultiBalanceRequest;
import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.application.service.MultiBalanceService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;

/**
 * <code>MultibalanceController</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@RestController
@RequestMapping(value = "/api")

/** The constant log. */
@Slf4j
public class MultibalanceController implements ContractDefinition {

  /** multi balance service. */
  private MultiBalanceService multiBalanceService;
  
  /**
   * Creates a new instance of multibalance controller.
   *
   * @param balanceService balance service
   */
  @Autowired
  public MultibalanceController(MultiBalanceService balanceService) {
    this.multiBalanceService = balanceService;
  }
  
  
  /* (non-Javadoc)
   * @see com.citibanamex.mafam.account.balances.application.controller.ContractDefinition
   */
  @Override
  public ResponseEntity<List<AccountBalance>> retrieveBalances(
      @RequestHeader(name = "client_id", required = true) String clientId,
      @RequestHeader(name = "Authorization", required = true) String authorization,
      @RequestHeader(name = "Accept", required = true) String accept,
      @RequestHeader(name = "uuid", required = true) String uuid,
      @RequestHeader(name = "Accept-Language", required = false) String acceptLanguage,
      @RequestHeader(name = "Content-Type", required = true) String contentType,
      @RequestHeader(name = "ChannelId", required = true) String channelId,
      @RequestHeader(name = "sid", required = true) String sid,
      @RequestBody @Valid MultiBalanceRequest serviceRequest) {
    
    log.info(
        "Headers: clientId[{}] acceptLanguage[{}] accept[{}] contentType[{}] channelId[{}] sid[{}]"
          + " uuid[{}]", clientId, acceptLanguage, accept, contentType, channelId, uuid, sid);
    log.info(serviceRequest.toString());
    
    Map<String, String> headers = new HashMap<>();
    headers.put("sid", sid);
    headers.put("ChannelId", channelId);
    headers.put("Accept", accept);
    headers.put("Accept-Language", acceptLanguage);
    headers.put("Content-Type", contentType);
    headers.put("Authorization", authorization);
    headers.put("uuid", uuid);
    headers.put("client_id", clientId);
    
    return new ResponseEntity<>(multiBalanceService.getBalances(headers, serviceRequest),
        HttpStatus.OK);
  }
}
