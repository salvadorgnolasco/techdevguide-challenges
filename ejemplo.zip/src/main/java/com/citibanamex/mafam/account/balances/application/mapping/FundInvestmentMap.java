/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.mapping;

import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.Account;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.FundInvestmentBalance;
import java.util.function.Function;

/**
 * <code>FundInvestmentMap</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class FundInvestmentMap implements Function<FundInvestmentBalance, AccountBalance> {

  /** account information. */
  private Account accountInformation;

  /**
   * Creates a new instance of fund investment map.
   *
   * @param accountInformation account information
   */
  public FundInvestmentMap(Account accountInformation) {
    this.accountInformation = accountInformation;
  }


  /* (non-Javadoc)
   * @see java.util.function.Function#apply(java.lang.Object)
   */
  @Override
  public AccountBalance apply(FundInvestmentBalance fundInvestmentBalance) {
    return AccountBalance.builder()
    .accountNumber(accountInformation.getAccountNumber().toString())
    .balance(fundInvestmentBalance.getInvestmentAccount().getStock().getHoldingPriceAmount())
    .branchId(accountInformation.getBranchId())
    .currencyCode(accountInformation.getCurrencyCode())
    .productCode(accountInformation.getProductCode())
    .productInstrument(accountInformation.getProductInstrument())
    .productName(fundInvestmentBalance.getInvestmentAccount().getProductInstrument())
    .build();
  }

}
