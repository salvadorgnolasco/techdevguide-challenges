/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.account.checking;

import com.citibanamex.mafam.account.balances.application.request.balance.AccountBalanceRequest;
import com.citibanamex.mafam.account.balances.domain.account.checking.CheckingAccount;
import com.citibanamex.mafam.account.balances.domain.account.checking.CheckingAccountBalance;

import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.hystrix.HystrixFeign;
import feign.slf4j.Slf4jLogger;

import java.util.Map;
import java.util.function.Supplier;

/**
 * <code>CheckingAccountBalanceRepository</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class CheckingAccountBalanceRepository implements Supplier<CheckingAccountBalance> {

  /** headers. */
  private Map<String, String> headers;
  
  /** request. */
  private AccountBalanceRequest request;
  
  /** service client. */
  private CheckingAccountBalanceClient serviceClient;
  
  /**
   * Creates a new instance of checking account balance repository.
   *
   * @param headerInformation header information
   * @param request request
   * @param target target
   */
  public CheckingAccountBalanceRepository(Map<String, String> headers,
      AccountBalanceRequest request, String target) {
    
    this.headers = headers;
    this.request = request;
    
    this.serviceClient = HystrixFeign.builder()
        .encoder(new GsonEncoder())
        .decoder(new GsonDecoder())
        .logger(new Slf4jLogger(CheckingAccountBalanceRepository.class))
        .logLevel(Logger.Level.FULL)
        .target(CheckingAccountBalanceClient.class, target, this::executeFallback);
  }
  
  /**
   * Execute fallback.
   *
   * @param headers headers
   * @param request request
   * @return checking account balance
   */
  public CheckingAccountBalance executeFallback(Map<String, String> headers,
      AccountBalanceRequest request) {
    CheckingAccountBalance response = new CheckingAccountBalance();
    response.setCheckingAccount(new CheckingAccount());
    
    return response;
  }
  
  /* (non-Javadoc)
   * @see java.util.function.Supplier#get()
   */
  @Override
  public CheckingAccountBalance get() {
    
    return serviceClient.getCheckingBalance(headers, request);
  }

}
