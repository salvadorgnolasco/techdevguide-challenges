/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.account.funds;

import com.citibanamex.mafam.account.balances.application.request.balance.AccountBalanceRequest;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.FundInvestmentBalance;

import feign.HeaderMap;
import feign.RequestLine;

import java.util.Map;

/**
 * <code>FundsInvestmentClient</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@FunctionalInterface
public interface FundsInvestmentClient {

  /**
   * Gets the fund investent balance.
   *
   * @param headers headers
   * @param request request
   * @return fund investent balance
   */
  @RequestLine("POST /api/v1/investments/accounts/holdings/retrieve")
  public abstract FundInvestmentBalance getFundInvestentBalance(
      @HeaderMap Map<String, String> headers, AccountBalanceRequest request);
}
