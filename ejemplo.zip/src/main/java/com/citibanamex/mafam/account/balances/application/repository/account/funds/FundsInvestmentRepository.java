/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.account.funds;

import com.citibanamex.mafam.account.balances.application.request.balance.AccountBalanceRequest;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.FundInvestmentBalance;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.InvestmentAccount;
import com.citibanamex.mafam.account.balances.domain.account.investment.funds.Stock;
import feign.HeaderMap;
import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.hystrix.HystrixFeign;
import feign.slf4j.Slf4jLogger;

import java.util.Map;
import java.util.function.Supplier;

/**
 * <code>FundsInvestmentRepository</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class FundsInvestmentRepository implements Supplier<FundInvestmentBalance> {

  /** headers. */
  private Map<String, String> headers;
  
  /** request. */
  private AccountBalanceRequest request;
  
  /** service client. */
  private FundsInvestmentClient serviceClient;

  /**
   * Creates a new instance of funds investment repository.
   *
   * @param header header
   * @param request request
   * @param target target
   */
  public FundsInvestmentRepository(Map<String, String> header, AccountBalanceRequest request,
      String target) {

    this.headers = header;
    this.request = request;
    this.serviceClient = HystrixFeign.builder()
        .encoder(new GsonEncoder())
        .decoder(new GsonDecoder())
        .logger(new Slf4jLogger(FundsInvestmentRepository.class))
        .logLevel(Logger.Level.FULL)
        .target(FundsInvestmentClient.class, target, this::executeFallback);
  }
  
  /**
   * Execute fallback.
   *
   * @param headers headers
   * @param request request
   * @return fund investment balance
   */
  public FundInvestmentBalance executeFallback(@HeaderMap Map<String, String> headers,
      AccountBalanceRequest request) {
    
    FundInvestmentBalance response = new FundInvestmentBalance();
    response.setInvestmentAccount(new InvestmentAccount());
    response.getInvestmentAccount().setStock(new Stock());
    
    return response;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.util.function.Supplier#get()
   */
  @Override
  public FundInvestmentBalance get() {
    return serviceClient.getFundInvestentBalance(headers, request);
  }

}
