/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.account.loan;

import com.citibanamex.mafam.account.balances.application.request.balance.AccountDataCenterBalanceRequest;
import com.citibanamex.mafam.account.balances.domain.account.loan.LoanAccount;
import com.citibanamex.mafam.account.balances.domain.account.loan.LoanAccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.loan.LoanPayment;

import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.hystrix.HystrixFeign;
import feign.slf4j.Slf4jLogger;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;

/**
 * <code>LoanAccountBalanceRepository</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class LoanAccountBalanceRepository implements Supplier<LoanAccountBalance> {

  /** headers. */
  private Map<String, String> headers;
  
  /** request. */
  private AccountDataCenterBalanceRequest request;
  
  /** service client. */
  private LoanAccountBalanceClient serviceClient;
  
  /**
   * Creates a new instance of loan account balance repository.
   *
   * @param headers headers
   * @param request request
   * @param target target
   */
  public LoanAccountBalanceRepository(Map<String, String> headers,
      AccountDataCenterBalanceRequest request, String target) {
    
    this.headers = headers;
    this.request = request;

    serviceClient = HystrixFeign.builder()
        .encoder(new GsonEncoder()).decoder(new GsonDecoder())
        .logger(new Slf4jLogger(LoanAccountBalanceRepository.class))
        .logLevel(Logger.Level.FULL)
        .target(LoanAccountBalanceClient.class, target, this::executeFallback);
  }
  
  /**
   * Execute fallback.
   *
   * @param headers headers
   * @param request request
   * @return loan account balance
   */
  public LoanAccountBalance executeFallback(Map<String, String> headers,
      AccountDataCenterBalanceRequest request) {   

    LoanPayment payments = new LoanPayment();
    payments.setAccount(new LoanAccount());
    LoanAccountBalance response = new LoanAccountBalance();
    response.setPayments(Arrays.asList(payments));
    
    return response;
  }
  
  /* (non-Javadoc)
   * @see java.util.function.Supplier#get()
   */
  @Override
  public LoanAccountBalance get() {
    
    return serviceClient.getLoanAccountBalance(headers, request);
  }
  
}
