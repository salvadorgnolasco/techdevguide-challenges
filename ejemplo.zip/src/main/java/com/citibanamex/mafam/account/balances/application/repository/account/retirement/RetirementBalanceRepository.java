/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.account.retirement;

import com.citibanamex.mafam.account.balances.application.request.balance.AccountBalanceRequest;
import com.citibanamex.mafam.account.balances.domain.account.investment.retirement.RetirementBalance;

import feign.HeaderMap;
import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.hystrix.HystrixFeign;
import feign.slf4j.Slf4jLogger;

import java.util.Map;
import java.util.function.Supplier;

/**
 * <code>RetirementBalanceRepository</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class RetirementBalanceRepository implements Supplier<RetirementBalance> {

  /** header information. */
  private Map<String, String> headerInformation;

  /** request. */
  private AccountBalanceRequest request;
  
  /** service client. */
  private RetirementBalanceClient serviceClient;
  
  /**
   * Creates a new instance of retirement balance repository.
   *
   * @param headerInformation header information
   * @param request request
   * @param target target
   */
  public RetirementBalanceRepository(Map<String, String> headerInformation,
      AccountBalanceRequest request, String target) {
    
    this.headerInformation = headerInformation;
    this.request = request;
    this.serviceClient = HystrixFeign.builder()
        .encoder(new GsonEncoder())
        .decoder(new GsonDecoder())
        .logger(new Slf4jLogger(RetirementBalanceRepository.class))
        .logLevel(Logger.Level.FULL)
        .target(RetirementBalanceClient.class, target, this::executeFallback);
  }
  
  /**
   * Execute fallback.
   *
   * @param headers headers
   * @param request request
   * @return retirement balance
   */
  public RetirementBalance executeFallback(@HeaderMap Map<String, String> headers,
      AccountBalanceRequest request) {
    return new RetirementBalance();
  }
  
  /* (non-Javadoc)
   * @see java.util.function.Supplier#get()
   */
  public RetirementBalance get() {
    return serviceClient.getRetirementBalance(headerInformation, request);
  }
  
}
