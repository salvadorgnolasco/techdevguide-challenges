/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.repository.customer;

import com.citibanamex.mafam.account.balances.application.request.customer.DataCenterLocationRequest;
import com.citibanamex.mafam.account.balances.domain.customer.Customer;
import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.hystrix.HystrixFeign;
import feign.slf4j.Slf4jLogger;

import java.util.Map;


/**
 * <code>CustomerRepository</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class CustomerRepository {

  /** customer service client. */
  private CustomerServiceClient customerServiceClient;

  /** customer. */
  private DataCenterLocationRequest dataCenterLocationRequest;

  /** header information. */
  private Map<String, String> headerInformation;

  /**
   * Creates a new instance of customer repository.
   *
   * @param headerInformation header information
   * @param dataCenterLocationRequest data center location request
   * @param target target
   */
  public CustomerRepository(Map<String, String> headerInformation, 
      DataCenterLocationRequest dataCenterLocationRequest,
      String target) {

    this.headerInformation = headerInformation;
    this.dataCenterLocationRequest = dataCenterLocationRequest;

    customerServiceClient = HystrixFeign.builder()
        .encoder(new GsonEncoder())
        .decoder(new GsonDecoder())
        .logger(new Slf4jLogger(CustomerRepository.class))
        .logLevel(Logger.Level.FULL)
        .target(CustomerServiceClient.class, target, (Map<String, String> headers,
            DataCenterLocationRequest request) -> { Customer c = new Customer();
            c.setDataCenterLocation(10);
            return c;});
  }

  /**
   * Gets the data center location.
   *
   * @return data center location
   */
  public Customer getDataCenterLocation() {
    
    return customerServiceClient.getDataCenter(headerInformation, dataCenterLocationRequest);
  }

}
