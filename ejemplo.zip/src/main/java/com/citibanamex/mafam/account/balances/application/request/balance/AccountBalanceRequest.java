/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.request.balance;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.toJsonString;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * <code>AccountBalanceRequest</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Getter
@Setter
@Builder
public class AccountBalanceRequest {

  /** account number. */
  private String accountNumber;

  /** data center location. */
  private Integer dataCenterLocation;
  
  /** branch id. */
  private String branchId;
  
  /** branch code. */
  private String branchCode;
  
  /** product instrument. */
  private String productInstrument;
  
  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  public String toString() {
    return toJsonString(() -> this);
  }
}
