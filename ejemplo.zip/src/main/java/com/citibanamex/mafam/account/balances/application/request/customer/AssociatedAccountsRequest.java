/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.request.customer;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.toJsonString;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * <code>AssociatedAccountsRequest</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Getter
@Setter
@AllArgsConstructor
public class AssociatedAccountsRequest {

  /** customer id. */
  private String customerId;

  /** data center location. */
  private int dataCenterLocation;

  /** page id. */
  private int pageId;
  
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return  toJsonString(() -> this);
  }
}
