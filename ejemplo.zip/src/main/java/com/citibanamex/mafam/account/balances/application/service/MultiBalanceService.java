/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.application.service;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.getAccountType;

import com.citibanamex.mafam.account.balances.application.aggregator.IDashboardAggregator;
import com.citibanamex.mafam.account.balances.application.request.MultiBalanceRequest;
import com.citibanamex.mafam.account.balances.application.response.AccountBalance;
import com.citibanamex.mafam.account.balances.domain.account.Account;
import com.citibanamex.mafam.account.balances.domain.account.AccountType;
import com.citibanamex.mafam.account.balances.domain.customer.AssociatedProfile;
import com.citibanamex.mafam.account.balances.domain.customer.Customer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <code>MultiBalanceService</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Component
@Scope("prototype")
@Slf4j
public class MultiBalanceService {
  
  /** La constante ACTIVE_ACCOUNT. */
  private static final int ACTIVE_ACCOUNT = 11;
  
  /** dashboard aggregator. */
  private IDashboardAggregator dashboardAggregator;

  /**
   * Creates a new instance of multi balance service.
   *
   * @param dashboardAggregator dashboard aggregator
   */
  public MultiBalanceService(IDashboardAggregator dashboardAggregator) {
    
    this.dashboardAggregator = dashboardAggregator;
  }
  
  /**
   * Gets the balances.
   *
   * @param headers headers
   * @param serviceRequest service request
   * @return balances
   */
  public List<AccountBalance> getBalances(Map<String, String> headers, 
      MultiBalanceRequest serviceRequest) {
    
    String customerId = serviceRequest.getCustomerId();
    int dataCenter = dashboardAggregator.getDataCenterLocation(headers, customerId);
    AssociatedProfile associatedProfile = 
        dashboardAggregator.getAssociatedProfile(headers, customerId, dataCenter);   
    
//    Map<AccountType, List<Account>> accounts =  
//        getAccountStream(serviceRequest.getAccounts(), associatedProfile)
//        .peek(a -> log.info(a.toString()))
//        .collect(Collectors.groupingBy(Account::getAccountType));
    
//    List<AccountBalance> balances = new ArrayList<>();
//    accounts.keySet()
//    .stream()
//    .map(k -> dashboardAggregator.supplyBalances(headers, accounts.get(k), dataCenter).get())
//    .forEach(balances::addAll);
//    
//    return balances;
//    
    List<Account> accounts =  getAccountStream(serviceRequest.getAccounts(), associatedProfile)
        .peek(a -> log.info(a.toString()))
        .collect(Collectors.toList());
    
    return dashboardAggregator.supplyBalances(headers, accounts, dataCenter).get();
    
//    ForkJoinPool forkJoinPool = null;    
//    
//    try {
//      forkJoinPool = new ForkJoinPool(10);      
//      
//      return 
//          forkJoinPool.submit(
//              () -> dashboardAggregator.supplyBalances(headers, accounts, dataCenter).get() ).get();
//    }catch(Exception e) {
//      log.error(e.getMessage(), e);
//      return null;
//    }finally {
//      if (forkJoinPool != null) {
//        forkJoinPool.shutdown();
//      }
//    }
  }  

  /**
   * Gets the account stream.
   *
   * @param accountsRequested accounts requested
   * @param associatedProfile associated profile
   * @return account stream
   */
  private Stream<Account> getAccountStream(Set<String> accountsRequested,
      AssociatedProfile associatedProfile) {

    Customer customerInformation = associatedProfile.getCustomer();

    return Stream.of(customerInformation.getAccounts()
        .toArray(new Account[customerInformation.getAccounts().size()]))
        .map(this::identifyAccountType)
        .filter(this::isAnActiveAccount)
        .filter(this::isCorrectAccountType)
        .filter(a -> accountsRequested.contains(a.getAccountNumber().toString()));
  }
  
  /**
   * Verify if that an active account is true.
   *
   * @param accountInformation account information
   * @return true, in case the condition is satisfied an active account
   */
  private boolean isAnActiveAccount(Account accountInformation) {
    return accountInformation.getAccountStatus() == ACTIVE_ACCOUNT;
  }
  
  /**
   * Verify if that correct account type is true.
   *
   * @param accountInformation account information
   * @return true, in case the condition is satisfied correct account type
   */
  private boolean isCorrectAccountType(Account accountInformation) {
    return accountInformation.getAccountType() != null;
  }

  /**
   * Identify account type.
   *
   * @param accountInformation account information
   * @return account
   */
  private Account identifyAccountType(Account accountInformation) {
    accountInformation.setAccountType(getAccountType(accountInformation.getProductCode()));
    return accountInformation;
  }

}

