/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.domain.account;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.toJsonString;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;

/**
 * <code>Account</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Getter
@Setter
@Builder
public class Account {

  /** account type. */
  private AccountType accountType;
  
  /** product code. */
  private int productCode;
  
  /** product instrument. */
  private int productInstrument;
    
  /** display account number. */
  private int displayAccountNumber;
  
  /** account number. */
  private BigInteger accountNumber;

  /** account status. */
  private int accountStatus;
 
  /** branch id. */
  private int branchId;
  
  /** currency code. */
  private int currencyCode;
  
  /** account ownership type. */
  private int accountOwnershipType;
  
  /** account creation date. */
  private String accountCreationDate;
  
  /** last updated date. */
  private String lastUpdatedDate;
  
  /** electronic banking usage code. */
  private int electronicBankingUsageCode;
  
  /** account association type. */
  private int accountAssociationType;
  
  /** account last three numbers. */
  private int accountLastThreeNumbers;
  
  /** joint relationship indicator. */
  private int jointRelationshipIndicator;
  
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    
    return toJsonString(() -> this);
  }
}
