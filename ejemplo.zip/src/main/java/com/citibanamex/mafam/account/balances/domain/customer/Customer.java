/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.domain.customer;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.toJsonString;

import com.citibanamex.mafam.account.balances.domain.account.Account;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * <code>Customer</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Getter
@Setter
public class Customer {

  /** customer id. */
  private String customerId;
  
  /** customer status. */
  private int customerStatus;
  
  /** data center location. */
  private int dataCenterLocation;
  
  /** more information flag. */
  private boolean moreInformationFlag;
   
  /** accounts. */
  private List<Account> accounts;
  
  /**
   * Creates a new instance of customer.
   */
  public Customer() {
    this(null, 0);
  }
  
  /**
   * Creates a new instance of customer.
   *
   * @param customerId customer id
   */
  public Customer(String customerId) {
    this(customerId, 0);
  }
  
  /**
   * Creates a new instance of customer.
   *
   * @param customerId customer id
   * @param dataCenterLocation data center location
   */
  public Customer(String customerId, int dataCenterLocation) {
    this.customerId = customerId;
    this.dataCenterLocation = dataCenterLocation;
  }
  
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return  toJsonString(() -> this);
  }
}
