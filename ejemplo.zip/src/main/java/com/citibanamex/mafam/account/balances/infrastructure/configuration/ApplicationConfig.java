/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.infrastructure.configuration;

import com.citibanamex.mafam.account.balances.application.aggregator.DashboardAggregator;
import com.citibanamex.mafam.account.balances.application.aggregator.IDashboardAggregator;

import lombok.extern.slf4j.Slf4j;

import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <code>ApplicationConfig</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Configuration
@Slf4j
public class ApplicationConfig {

  
  /**
   * Dashboard aggregator.
   *
   * @param discoveryClient discovery client
   * @return i dashboard aggregator
   */
//  @Bean
  public IDashboardAggregator dashboardAggregator(DiscoveryClient discoveryClient) {
    return new DashboardAggregator(s -> {
      if (!discoveryClient.getInstances(s).isEmpty()) {
        log.info(discoveryClient.getInstances(s).get(0).getUri().toString());
        return "http://localhost:9999";
      } else {
        return "http://localhost:9999";
      }
    });
  }
  
  /**
   * Dashboard aggregator.
   *
   * @param discoveryClient discovery client
   * @return i dashboard aggregator
   */
  @Bean
  public IDashboardAggregator dashboardAggregator() {
    return new DashboardAggregator(s -> "http://localhost:9999");
  }
  
}
