/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.infrastructure.exception;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * <code>ErrorResponse</code>.
 *
 * @author em98168
 * @version 1.0
 */
public class ErrorResponse {

  /** The constant type. */
  private final String type;

  /** The constant code. */
  private final String code;

  /** The constant details. */
  private final String details;

  /** The constant location. */
  private final String location;

  /** The constant moreInfo. */
  private final String moreInfo;


  /**
   * Creates a new instance of error response.
   *
   * @param type type
   * @param code code
   * @param details details
   * @param location location
   * @param moreInfo more info
   */
  public ErrorResponse(String type, String code, String details,
      String location, String moreInfo) {

    super();
    this.type = type;
    this.code = code;
    this.details = details;
    this.location = location;
    this.moreInfo = moreInfo;
  }

  /**
   * Gets the type.
   *
   * @return type
   */
  public String getType() {

    return type;
  }

  /**
   * Gets the code.
   *
   * @return code
   */
  public String getCode() {

    return code;
  }

  /**
   * Gets the details.
   *
   * @return details
   */
  public String getDetails() {

    return details;
  }

  /**
   * Gets the location.
   *
   * @return location
   */
  public String getLocation() {

    return location;
  }

  /**
   * Gets the more info.
   *
   * @return more info
   */
  public String getMoreInfo() {

    return moreInfo;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {

    return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
  }

}
