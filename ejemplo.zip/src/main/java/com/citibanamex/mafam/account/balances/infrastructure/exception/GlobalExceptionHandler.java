/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.infrastructure.exception;

import lombok.extern.slf4j.Slf4j;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <code>GlobalExceptionHandler</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@ControllerAdvice

/** The constant log. */
@Slf4j
public class GlobalExceptionHandler {

  /**
   * Bad request.
   *
   * @param exc exc
   * @return response entity
   */
  @ExceptionHandler({HttpMessageNotReadableException.class,
      MethodArgumentNotValidException.class})
  public ResponseEntity<ErrorResponse> badRequest(Exception exc) {

    log.info(exc.getMessage());
    String message = exc.getClass().getSimpleName();

    String moreInfo = exc instanceof MethodArgumentNotValidException
        ? getMoreInfoFromArgumentNotValid((MethodArgumentNotValidException) exc)
        : exc.getMessage();

    return new ResponseEntity<>(
      new ErrorResponse("invalid", "400", message, "request", moreInfo),
      HttpStatus.BAD_REQUEST);
  }

  /**
   * Gets the more info from argument not valid.
   *
   * @param exc exc
   * @return more info from argument not valid
   */
  private String
      getMoreInfoFromArgumentNotValid(MethodArgumentNotValidException exc) {
    
    StringBuilder errorMessage = new StringBuilder();
    
    Stream
        .of(exc.getBindingResult().getAllErrors().toArray(new ObjectError[0]))
        .map(err -> ((DefaultMessageSourceResolvable) 
               err.getArguments()[0]).getCode() + ", " + err.getDefaultMessage() + ". ")
        .collect(Collectors.toSet())
        .forEach(errorMessage::append);
    
    return errorMessage.toString();
  }

}
