/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.infrastructure.util;

import com.citibanamex.mafam.account.balances.domain.account.AccountType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.function.Supplier;
import javax.annotation.PostConstruct;


/**
 * <code>ApplicationUtil</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Component
public class ApplicationUtil {

  /** The constant DEFAULT_CSI. */
  public static final int DEFAULT_CSI = 10;
  
  /** The constant productMapping. */
  private static final HashMap<Integer, AccountType> productMapping = new HashMap<>();

  /**
   * Creates a new instance of application util.
   */
  public ApplicationUtil() {
    createProductMap();
  }

  /**
   * Gets the account type.
   *
   * @param productCode product code
   * @return account type
   */
  public static AccountType getAccountType(Integer productCode) {
    return productMapping.get(productCode);
  }

  /**
   * Verify if that valid product is true.
   *
   * @param productCode product code
   * @return true, in case the condition is satisfied valid product
   */
  public static boolean isValidProduct(Integer productCode) {
    return productMapping.containsKey(productCode);
  }
  
  /**
   * To string.
   *
   * @param <T> generic type
   * @param objectSupplier object supplier
   * @return string JSON style
   */
  public static <T> String toJsonString(Supplier<T> objectSupplier) {
    return ToStringBuilder.reflectionToString(objectSupplier.get(), ToStringStyle.JSON_STYLE);
  }


  /**
   * Creates the product map.
   */
  @PostConstruct
  private void createProductMap() {
    
    if (!productMapping.isEmpty()) {
      return;
    }
    
    addProducts(Arrays.asList(1), AccountType.CHECKING);
    addProducts(Arrays.asList(66, 500), AccountType.MASTER);
    addProducts(Arrays.asList(87), AccountType.FIXED_TERM_INVESTMENT);
    addProducts(Arrays.asList(84), AccountType.FUNDS_INVESTMENT);
    addProducts(Arrays.asList(111, 112, 113, 114, 5446, 8548), AccountType.CARDS);
    addProducts(Arrays.asList(333, 336), AccountType.RETIREMENT);
    addProducts(Arrays.asList(100, 140, 600), AccountType.LOAN);
  }

  /**
   * Adds the products.
   *
   * @param productList product list
   * @param accountType account type
   */
  private void addProducts(List<Integer> productList, AccountType accountType) {
    productList.stream().forEach(p -> productMapping.put(p, accountType));
  }

}
