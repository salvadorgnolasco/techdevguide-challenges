package com.citibanamex.mafam.account.balances.application;

public class Test {

}
