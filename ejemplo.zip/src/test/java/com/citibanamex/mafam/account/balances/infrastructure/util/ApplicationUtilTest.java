/*
* Copyright (C) 2016 by Citigroup. All rights reserved.
* Citigroup claims copyright in this computer program as an unpublished work,
* one or more versions of which were first used to provide services to
* customers on the dates indicated in the foregoing notice. Claim of
* copyright does not imply waiver of other rights.
*
* NOTICE OF PROPRIETARY RIGHTS
*
* This program is a confidential trade secret and the property of Citigroup.
* Use, examination, reproduction, disassembly, decompiling, transfer and/or
* disclosure to others of all or any part of this software program are
* strictly prohibited except by express written agreement with Citigroup.
*/

package com.citibanamex.mafam.account.balances.infrastructure.util;

import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.getAccountType;
import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.isValidProduct;
import static com.citibanamex.mafam.account.balances.infrastructure.util.ApplicationUtil.toJsonString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.citibanamex.mafam.account.balances.domain.account.AccountType;

import org.junit.Test;

import java.util.function.Predicate;

/**
 * <code>ApplicationUtilTest</code>.
 *
 * @author sg05070
 * @version 1.0
 */
public class ApplicationUtilTest {

  /**
   * Given a product code 
   * When the value is provided 
   * Then the method should give the correct product type.
   */
  @Test
  public void shouldGiveTheCorrectProductType() {
    new ApplicationUtil();
    assertEquals(AccountType.CHECKING, getAccountType(1));
    assertEquals(AccountType.MASTER, getAccountType(66));
    assertEquals(AccountType.MASTER, getAccountType(500));
    assertEquals(AccountType.FIXED_TERM_INVESTMENT, getAccountType(87));
    assertEquals(AccountType.FUNDS_INVESTMENT, getAccountType(84));
    assertEquals(AccountType.CARDS, getAccountType(111));
    assertEquals(AccountType.CARDS, getAccountType(112));
    assertEquals(AccountType.CARDS, getAccountType(113));
    assertEquals(AccountType.CARDS, getAccountType(114));
    assertEquals(AccountType.CARDS, getAccountType(5446));
    assertEquals(AccountType.CARDS, getAccountType(8548));
    assertEquals(AccountType.RETIREMENT, getAccountType(333));
    assertEquals(AccountType.RETIREMENT, getAccountType(336));
    assertEquals(AccountType.LOAN, getAccountType(100));
    assertEquals(AccountType.LOAN, getAccountType(140));
    assertEquals(AccountType.LOAN, getAccountType(600));
  }

  /**
   * Given a product code 
   * When a correct product code is provided 
   * Then the method should valid the product code and return true.
   */
  @Test
  public void shouldValidProductCode() {
    assertTrue(isValidProduct(1));
    assertTrue(isValidProduct(66));
    assertTrue(isValidProduct(500));
    assertTrue(isValidProduct(87));
    assertTrue(isValidProduct(84));
    assertTrue(isValidProduct(111));
    assertTrue(isValidProduct(112));
    assertTrue(isValidProduct(113));
    assertTrue(isValidProduct(114));
    assertTrue(isValidProduct(5446));
    assertTrue(isValidProduct(8548));
    assertTrue(isValidProduct(333));
    assertTrue(isValidProduct(336));
    assertTrue(isValidProduct(100));
    assertTrue(isValidProduct(140));
    assertTrue(isValidProduct(600));
  }

  /**
   * Given a product code 
   * When a wrong product code is provided 
   * Then the method should valid the product code and return false.
   */
  @Test
  public void shouldValidWrongProductCode() {
    assertFalse(isValidProduct(2));
    assertFalse(isValidProduct(77));
    assertFalse(isValidProduct(800));
    assertFalse(isValidProduct(5));
  }

  /**
   * Given an object 
   * When it needs to be printed 
   * Then the method should return a JSON string.
   */
  @Test
  public void shouldReturnJsonString() {
    assertEquals("{\"customerId\":\"15\"}", toJsonString(() -> {
      return new Predicate<String>() {

        private String customerId = "15";

        @SuppressWarnings("unused")
        public String getCustomerid() {
          return customerId;
        }

        @Override
        public boolean test(String arg0) {
          return false;
        }

      };
    }));
  }

}
